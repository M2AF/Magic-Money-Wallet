import { c as createExtensionWallet, a as createRoot, j as jsxRuntimeExports, r as reactExports, E as ExtApp } from "./chunks/index-BNDYEtz1.js";
window.__SIDE_PANEL__ = true;
window.wallet = createExtensionWallet();
const root = document.getElementById("root");
createRoot(root).render(
  /* @__PURE__ */ jsxRuntimeExports.jsx(reactExports.StrictMode, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(ExtApp, {}) })
);
